package test;

public class MR extends Employee
{
	int stsupported;
	String taskassign;
	
	public void info()
	{
		super.info();
		
		System.out.println("enter the number of student supported");
		stsupported=sc.nextInt();
		
		System.out.println("enter the task assign ");
		taskassign=sc.next();
	}
	
	public void display()
	{
		super.display();
		System.out.println("Number of students supported are: "+stsupported);
		System.out.println("Task assign is: "+taskassign);
	}
}
