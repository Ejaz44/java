package test;

import java.util.Scanner;

public abstract class Employee 
{
	String fname,lname,gender,email;
	int age;
	Address address = new Address();  
	Scanner sc=new Scanner(System.in);
	
	public void info()
	{
		System.out.println("enter your first name");
		fname=sc.next();
		
		
		System.out.println("enter your last name");
		lname=sc.next();
		
		System.out.println("enter your gender");
		gender=sc.next();
		
		System.out.println("enter your email");
		email=sc.next();
		
		address.Add();
		
		System.out.println("enter your age");
		age=sc.nextInt();
		
		
	}
	public void display()
	{
		System.out.println("first name is: "+fname);
		System.out.println("last name is: "+lname);
		System.out.println("Gender is: "+gender);
		System.out.println("Email is: "+email);
		address.disp();
		System.out.println("age is: "+age);
		
	}
}
