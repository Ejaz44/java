package test;

public class Centerhead extends Employee
{
	int placement;
	
	public void info()
	{
		super.info();
		
		System.out.println("enter the number of placements");
		placement=sc.nextInt();
	}
	
	public void display()
	{
		super.display();
		System.out.println("number of placements are: "+placement);
	}
}
