package test;

public class Faculty extends Employee 
{
	int students;
	String coursename,time;
	
	public void info()
	{
		super.info();
		
		System.out.println("enter your batch timing");
		time=sc.next();
		
		System.out.println("enter your course name");
		coursename=sc.next();
		
		System.out.println("enter your number of students");
		students=sc.nextInt();
	}
	
	public void display()
	{
		super.display();
		System.out.println("Batch timing is: "+time);
		System.out.println("Course name is: "+coursename);
		System.out.println("Number of students is: "+students);
	}
	
}
