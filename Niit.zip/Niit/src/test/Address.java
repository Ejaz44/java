package test;

import java.util.Scanner;

public class Address 
{
	Scanner aj = new Scanner(System.in);
	
	String city, state;
	int flatNo;
	
	public void Add()
	{
		System.out.println("Enter your Address: ");
		
		System.out.println("Enter your flat-no: ");
		flatNo = aj.nextInt();
		
		System.out.println("Enter your City: ");
		city = aj.next();
		
		System.out.println("Enter your state: ");
		state = aj.next();
	}
	
	public void disp()
	{
		System.out.println("your flat-no is: "+flatNo);
		System.out.println("your city is: "+city);
		System.out.println("Enter your state: "+state);
		
	}
	
}

