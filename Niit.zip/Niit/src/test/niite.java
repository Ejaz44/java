package test;

import java.util.Scanner;

public class niite {

	public static void main(String[] args) 
	{
	MR mrd=new MR();
	Faculty ff=new Faculty();
	Centerhead cc=new Centerhead();
	GroupLead gg=new GroupLead();
	System.out.println("1.faculty");
	System.out.println("2.MR");
	System.out.println("3.Centerhead");
	System.out.println("4.Grouplead");
	Scanner ob=new Scanner(System.in);
	int i = ob.nextInt();
	switch (i) {
	case 1:ff.info();
			ff.display();
		
		break;

	case 2:mrd.info();
			mrd.display();
			break;
			
	case 3:cc.info();
			cc.display();
			break;
			
	case 4:gg.info();
			gg.display();
			break;
	}


	}

}
