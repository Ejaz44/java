package test;

public class GroupLead extends Employee 
{
	int batchlaunch, CR, MR;
	
	public void info()
	{
		super.info();
		
		System.out.println("enter the number of batch launch");
		batchlaunch=sc.nextInt();
		
		System.out.println("enter the number of CR");
		CR=sc.nextInt();
		
		System.out.println("enter the number of MR");
		MR=sc.nextInt();
	}
	
	public void display()
	{
		super.display();
		System.out.println("NUmber of batch launch is: "+batchlaunch);
		System.out.println("Number of CR are "+CR);
		System.out.println("Numberof MR are is: "+MR);
	}
	
	
}
